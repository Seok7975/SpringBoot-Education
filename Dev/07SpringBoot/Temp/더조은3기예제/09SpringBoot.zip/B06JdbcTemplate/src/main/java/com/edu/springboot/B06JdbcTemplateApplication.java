package com.edu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B06JdbcTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(B06JdbcTemplateApplication.class, args);
	}

}
