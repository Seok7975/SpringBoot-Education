package com.edu.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B04ValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
