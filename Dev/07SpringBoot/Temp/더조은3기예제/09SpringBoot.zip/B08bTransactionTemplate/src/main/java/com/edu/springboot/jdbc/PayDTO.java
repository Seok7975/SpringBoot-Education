package com.edu.springboot.jdbc;

import lombok.Data;

@Data
public class PayDTO {
	private String userid;
    private int amount;
}
 