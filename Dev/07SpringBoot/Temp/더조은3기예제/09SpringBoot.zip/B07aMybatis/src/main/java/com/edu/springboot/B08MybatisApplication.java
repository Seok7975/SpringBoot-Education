package com.edu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B08MybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(B08MybatisApplication.class, args);
	}

}
