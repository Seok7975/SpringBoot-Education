package com.edu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B21WebSocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(B21WebSocketApplication.class, args);
	}

}
