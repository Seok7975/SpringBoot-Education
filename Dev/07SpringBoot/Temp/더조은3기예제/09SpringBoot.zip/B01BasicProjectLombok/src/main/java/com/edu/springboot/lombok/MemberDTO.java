package com.edu.springboot.lombok;

import lombok.Data;

@Data
public class MemberDTO {
	private String id;
	private String pass;
	private String name;
	private String regidate;
}

