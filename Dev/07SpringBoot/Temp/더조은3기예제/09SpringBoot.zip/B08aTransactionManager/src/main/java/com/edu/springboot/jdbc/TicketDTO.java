package com.edu.springboot.jdbc;

import lombok.Data;

@Data
public class TicketDTO {
	private String userid;
    private int t_count;
}
