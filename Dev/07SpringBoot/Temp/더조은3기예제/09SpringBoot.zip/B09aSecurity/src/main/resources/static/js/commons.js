//이름이 있는 유기명함수로 정의 (경고창을 띄워줌)
function myAlert(){
	alert("경고창이 표시됩니다.")	
}

//이름이 없는 무기명함수로 정의 (콘솔에 파라미터를 출력함)
let myConsole = function(param){
	console.log("파라미터:"+ param);
}
