package com.edu.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B10bSecurityCustomLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
