package com.edu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B04DiApplication {

	public static void main(String[] args) {
		SpringApplication.run(B04DiApplication.class, args);
	}

}
